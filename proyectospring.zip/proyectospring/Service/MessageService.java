package minticg25.proyectospring.Service;

import minticg25.proyectospring.Model.Message;
import java.util.List;
import java.util.Optional;


public interface MessageService{

    public List<Message> listarMessage();
    public Optional<Message> listarMessageId(Integer Id);
    public Message guardarMessageId(Message c);
    public boolean borrarMessageId(Integer id);
    
}