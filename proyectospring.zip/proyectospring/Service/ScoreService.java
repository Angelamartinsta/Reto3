package minticg25.proyectospring.Service;

import minticg25.proyectospring.Model.Score;
import java.util.List;
import java.util.Optional;


public interface ScoreService{

    public List<Score> listarScore();
    public Optional<Score> listarScoreId(Integer Id);
    public Score guardarScoreId(Score c);
    public boolean borrarScoreId(Integer id);
    
}