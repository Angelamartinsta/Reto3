package minticg25.proyectospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectospringApplication.class, args);
	}

}
