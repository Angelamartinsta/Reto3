package minticg25.proyectospring.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import minticg25.proyectospring.Model.Score;

@Repository
public interface ScoreCrudRepository extends CrudRepository<Score,Integer> {

}
