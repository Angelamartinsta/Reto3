package minticg25.proyectospring.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import minticg25.proyectospring.Model.Client;

@Repository
public interface ClientCrudRepository extends CrudRepository<Client,Integer> {

}
