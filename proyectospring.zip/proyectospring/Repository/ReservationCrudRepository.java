package minticg25.proyectospring.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import minticg25.proyectospring.Model.Reservation;

@Repository
public interface ReservationCrudRepository extends CrudRepository<Reservation,Integer> {

}
