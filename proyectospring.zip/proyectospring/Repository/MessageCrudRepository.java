package minticg25.proyectospring.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import minticg25.proyectospring.Model.Message;

@Repository
public interface MessageCrudRepository extends CrudRepository<Message,Integer> {

}
